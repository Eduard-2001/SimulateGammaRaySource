#!/usr/bin/env python
# coding: utf-8

# In[2]:


import numpy as np
import re
import matplotlib.pyplot as plt
from scipy import interpolate
import tqdm
import PSF

x = np.linspace(-2,2,201)
y = np.linspace(-2,2,201)
xx,yy = np.meshgrid(x,y)
z = np.zeros_like(xx)
z[100:150,20:40] += 1
psfconv = PSF.csinterp(1)
plt.imshow(z)
plt.figure()
plt.imshow(psfconv(z,xx,yy))
plt.show()

